let taskList = [];
let taskDoneList = [];
let removedTasks = [];

function taskLoad(){
    let list = localStorage.getItem('taskList'); // pega os dados armazenados taskList e atribui à "list"
    taskList = list ? JSON.parse(list) : []; //? verifica se há dados armazenados. True: converte em um array JavaScript usando JSON.parse() / False: inicializa taskList como um array vazio
    
    let removedTasksJSON = localStorage.getItem('removedTasks');
    removedTasks = removedTasksJSON ? JSON.parse(removedTasksJSON) : [];
    
    let doneTasksJSON = localStorage.getItem('taskDoneList');
    taskDoneList = doneTasksJSON ? JSON.parse(doneTasksJSON) : [];
    
    console.log("taskList:", taskList);
    console.log("removedTasks:", removedTasks);
    console.log("taskDoneList:", taskDoneList);

    updateTasks();
}


function addTask(event) {
    event.preventDefault(); // impede a página de recarregar
    let description = document.getElementById('description');
    if (description.value == '') {
        showMessage(); // Chama "Mensagem de erro"
    } else {
        taskList.push(description.value);
        localStorage.setItem('taskList', JSON.stringify(taskList)) // armazena a tasklist em formato string json no localStorage
        description.value = ''; // limpa o campo
        updateTasks(); // Chama "Adicionar a tarefa"
    }
}

function closeMessage() { // Fechar mensagem de erro
    let alert = document.getElementById('alert');
    alert.style.display = 'none'; // torna a mensagem de erro invisível
}

function showMessage() { // Mensagem de erro
    let message_type = document.getElementById('message_type');
    message_type.innerText = 'Erro: '; // define o texto a ser exibido

    let message = document.getElementById('message');
    message.innerText = 'Você precisa descrever a nova tarefa.'; // define o texto a ser exibido

    let alert = document.getElementById('alert');
    alert.style.display = 'block';
    setTimeout(() => { // inicia um timer de 4s (4000 ms)
        closeMessage(); // Chama "Fechar mensagem de erro"
    }, 4000); 
}

function updateTasks() { // Adicionar a tarefa 
    let divTasks = document.getElementById('tasks');
    const button = document.getElementById ('randomButton'); // cria uma variável

    if (taskList.length > 0) {
        let newOl = document.createElement('ol'); // cria uma lista ordenada 

        taskList.forEach((task, task2) => {
            let newLi = document.createElement('li'); // cria um li
            newLi.innerText = task; // adiciona o texto da task no li

            let removeButton = document.createElement('button'); // cria um button
            removeButton.innerText = 'x'; // adiciona o texto "x" no button
            removeButton.classList.add('removebutton'); // cria a classe "removebutton" para o button
            removeButton.onclick = () => removeTask(task2); // chama a função removeTask com o argumento da task removida

            let doneButton = document.createElement('button'); // cria um button
            doneButton.innerText = '✔'; // adiciona o texto "✔" no button
            doneButton.classList.add('donebutton'); // cria a classe "donebutton" para o button
            doneButton.onclick = () => doneTask(task2); // chama a função doneTask com o argumento da Li que está sendo criada

            newLi.appendChild(doneButton); // adiciona o donebutton como "filho" do li
            newLi.appendChild(removeButton); // adiciona o removebutton como "filho" do li

            if (taskDoneList.includes(task2)) {
                newLi.classList.add('donetask');
            }

            newOl.appendChild(newLi); // adiciona o li como "filho" do ol
            
        });

        divTasks.replaceChildren(newOl); // substitui tudo que tinha dentro da div tasks pelo ol
        button.removeAttribute('disabled'); // ativa o botão (quando houver task)
    }else{ // faz aparecer o texto caso não tenha nenhuma task 
        let p = document.createElement('p'); // cria um parágrafo
        p.innerText = 'Insira a primeira tarefa para começar....'; // adiciona o texto no button
        divTasks.replaceChildren(p); // substitui tudo que tinha dentro da div tasks pelo p

        button.setAttribute('disabled', ''); // desativa o botão (quando não houver task)
    }
    
}

function removeAll() { // Remove todas as tasks 
    taskList = [];
    localStorage.setItem('taskList', taskList) // torna o taskList localStorage vazio
    updateTasks(); // Chama "Adicionar a tarefa" para que o texto reapareça
}

function randomTask() { // Escolhe uma task aleatória
    if (taskList.length > 0) { // faz a função só ser executada caso tenha tasks na lista
    let randomNumber = Math.floor(taskList.length*Math.random()); // escolhe um número aleatório entre 0 e o total de tasks
        alertTask(taskList[randomNumber]);  // chama a função alertTask usando taskList[randomNumber] como argumento
    }
}

function alertTask(task) { // Alerta a task
    alert("Você deve fazer: " + task) // mostra um alerta com a task selecionada
}

function removeTask(removed) { // Remove a task escolhida
    console.log("Tarefa removida:", taskList[removed]);
    taskList.splice(removed,1);
    removedTasks.push(removed);
    console.log("removedTasks atualizado:", removedTasks);

    updateTasks();
}

function doneTask(checkTask) {  // Adiciona ou remove a task da taskDoneList
    if (taskDoneList.includes(checkTask)) { // checa se a task está na lista
        const indexToRemove = taskDoneList.indexOf(checkTask);
        taskDoneList.splice(indexToRemove, 1);
    } else {
        taskDoneList.push(checkTask); // adiciona a task na lista
    }

    console.log("Tarefa concluída:", taskList[checkTask]);
    console.log("taskDoneList atualizado:", taskDoneList);

    updateTasks();
}

